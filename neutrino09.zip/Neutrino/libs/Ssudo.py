#!/usr/bin/ env python
# -*- coding: utf-8 -*-

#Neutrino Project
#por Cleiton Lima <cleitonlima@fedoraproject.org>

#This file is part of Neutrino Project.

#    Neutrino is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.

#    Neutrino is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Neutrino.  If not, see <http://www.gnu.org/licenses/>.

#Setup sudo in Fedora
from os import getlogin, getenv, chdir
from dialog import *
from dialog_ok import *
from dialog_error import *

def install():
	file = open("/tmp/neutrino/text_var", "w")
	file.write("Deseja executar a modificação?")
	file.close()
	app = QtGui.QApplication(sys.argv)
	ex = NoYes()
	ex.show()
	app.exec_()
	set = str(open("/tmp/neutrino/dialog_var").read())
	if set == 'ok':
		try:
			install()
			line = str("\n")
			user = str(getlogin())
			print user
			cmd = str(" ALL=(ALL) NOPASSWD:ALL")
			chdir(str("/etc/"))
			sudoers = open ('sudoers', 'r').readlines()
			sudoers.append(line+user+cmd)
			sudo = open('sudoers', 'w')
			sudo.writelines(sudoers)
			sudo.close
		except:
			pass
		file = open("/tmp/neutrino/text_var", "w")
		file.write("Processo Concluído.")
		file.close()
		app1 = QtGui.QApplication(sys.argv)
		ex1 = Ok()
		ex1.show()
		app1.exec_()
	else:
		file = open("/tmp/neutrino/text_var", "w")
		file.write("Processo Cancelado.")
		file.close()
		app1 = QtGui.QApplication(sys.argv)
		ex1 = OkCancel()
		ex1.show()
		app1.exec_()
install()

SUDO_DESCRIPTION = str("Configurar o uso do Sudo no Fedora.")